# -*- coding: utf-8 -*-
import pymongo
from scrapy.exceptions import DropItem

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


class ScrapycrawlPipeline(object):
    def __init__(self, server, database, collection):
        connection = pymongo.MongoClient(server)
        db = connection[database]
        self.collection = db[collection]

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            server=crawler.settings.get('MONGODB_SERVER'),
            database=crawler.settings.get('MONGODB_DB'),
            collection=crawler.settings.get('MONGODB_COLLECTION')
        )

    def process_item(self, item, spider):
        valid = True
        for data in item:
            if not data:
                valid = False
                raise DropItem("Missing {0}!".format(data))

        if valid:
            self.collection.insert(dict(item))